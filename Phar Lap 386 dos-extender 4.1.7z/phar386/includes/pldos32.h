/* PLDOS32.H - Protected mode DOS interface routines in DOS32.LIB */
/* $Id: pldos32.h 1.2 91/10/23 16:53:21 rwm Exp $ */

/************************************************************************/
/*	Copyright (C) 1986-1991 Phar Lap Software, Inc.			*/
/*	Unpublished - rights reserved under the Copyright Laws of the	*/
/*	United States.  Use, duplication, or disclosure by the 		*/
/*	Government is subject to restrictions as set forth in 		*/
/*	subparagraph (c)(1)(ii) of the Rights in Technical Data and 	*/
/*	Computer Software clause at 252.227-7013.			*/
/*	Phar Lap Software, Inc., 60 Aberdeen Ave., Cambridge, MA 02138	*/
/************************************************************************/

/*	

	FILE DESCRIPTION

This include file contains definitions for the MS-DOS system
call library DOS32.LIB

*/

#ifndef PLTYPES
#include <pltypes.h>
#endif

/*	
 * Function prototypes for C-callable routines in DOS32.LIB, to make
 * 32-bit DOS INT 21h system calls from C.
 *
 * All functions return an _DOSE_ error code, a zero value (_DOSE_NONE) 
 * meaning no error.
 */

#ifndef PLDOS32DEFS
#define PLDOS32DEFS

/* INT 21h AH=01h - Character input with echo */
extern int _dos_char_ine(UCHAR *chp);
/* INT 21h AH=02h - Character output */
extern int _dos_char_out(UCHAR ch);
/* INT 21h AH=09h - Output character string */
extern int _dos_str_out(UCHAR *strp);
/* INT 21h AH=0Ah - Buffered input */
extern int _dos_buff_in(UCHAR *bufp);
/* INT 21h AH=30h - Get MS-DOS and 386|DOS-X version number */
extern int _dos_ver(ULONG dxinfo, ULONG *verp, ULONG *dxverp, ULONG *dxenvp);
/* INT 21h AH=3Ch - Create file */
extern int _dos_create(UCHAR *fnamep, USHORT attr, USHORT *handlep);
/* INT 21h AH=3Dh - Open file */
extern int _dos_open(UCHAR *fnamep, USHORT attr, USHORT *handlep);
/* INT 21h AH=3Eh - Close file */
extern int _dos_close(USHORT handle);
/* INT 21h AH=3Fh - Read file or device */
extern int _dos_read(USHORT handle, int nbytes, FARPTR bufp, int *nreadp);
/* INT 21h AH=40h - Write file or device */
extern int _dos_write(USHORT handle, int nbytes, FARPTR bufp, int *nwritep);
/* INT 21h AH=41h - Delete file */
extern int _dos_delete(UCHAR *fnamep);
/* INT 21h AH=42h - Seek in file */
extern int _dos_seek(USHORT handle, int origin, LONG offset,ULONG *new_filep);
/* INT 21h AH=46h - Force duplicate of handle */
extern int _dos_force_hnd(USHORT hnd, USHORT newhnd);
/* INT 21h AH=48h - Allocate segment */
extern int _dos_seg_alloc(ULONG npages, USHORT *selectorp, ULONG *maxpgsp);
/* INT 21h AH=49h - Free segment */
extern int _dos_seg_free(USHORT selector);
/* INT 21h AH=4Ah - Resize segment */
extern int _dos_seg_resize(USHORT selector, ULONG npages, ULONG *maxpgsp);
/* INT 21h AX=5801h - Set conventional memory allocation strategy */
extern int _dos_alloc_sset(USHORT strategy);
/* INT 21h AX=5800h - Get conventional memory allocation strategy */
extern int _dos_alloc_sget(USHORT *stratp);

#endif
