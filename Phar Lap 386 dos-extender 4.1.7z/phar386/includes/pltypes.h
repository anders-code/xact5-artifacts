/* PLTYPES.H - Definitions for Phar Lap standard data types 		*/
/* $Id: pltypes.h 1.4 91/06/18 15:38:08 jmb Exp $ */
/************************************************************************/
/*	Copyright (C) 1986-1988 Phar Lap Software, Inc.			*/
/*	Unpublished - rights reserved under the Copyright Laws of the	*/
/*	United States.  Use, duplication, or disclosure by the 		*/
/*	Government is subject to restrictions as set forth in 		*/
/*	subparagraph (c)(1)(ii) of the Rights in Technical Data and 	*/
/*	Computer Software clause at 252.227-7013.			*/
/*	Phar Lap Software, Inc., 60 Aberdeen Ave., Cambridge, MA 02138	*/
/************************************************************************/

#ifndef PLTYPES
#define PLTYPES

/*
	In order to be able to use this file with the EFI Libraries,
	I had to check the symbol below to make sure that these
	basic data types are not multiply-defined.  This symbol is
	set whenever the OS2 file "os2.h" is included (therefore,
	if the file "os2.h" will be used, it must be included
	BEFORE this file).
*/

#ifndef STDPL
#ifndef OS2_INCLUDED

/*
/*
 * Data types.  SHORT and LONG data types are guaranteed to be set up
 * as 16 and 32 bit data types, respectively, for all systems.
 */

typedef unsigned char UCHAR;	/* unsigned 8-bit value */
typedef short SHORT;		/* signed 16-bit value */
typedef unsigned short USHORT;	/* unsigned 16-bit value */
typedef unsigned int UINT;	/* unsigned integer */
typedef long LONG;		/* signed 32-bit value */
typedef unsigned long ULONG;	/* unsigned 32-bit value */
/* TBC - BOOL is a conflicting data type between OS2 and DOSX */
typedef int BOOL;		/* Boolean value */


/*
 * Special values
 */
#define TRUE	1		/* Boolean true */
#define FALSE	0		/* Boolean false */

#endif /* OS2_INCLUDED */

typedef void *PTR;		/* generic pointer */
#define EOS  '\0'		/* end-of-string character */

#endif /* STDPL */


/*

Real mode pointer data type (segment:offset16)

The REALPTR data type is used in protected mode to hold
real mode pointers.  The data type is an unsigned long value.
The upper 16 bits of the long are a segment number and the lower
16 bits of the long are an offset.  The format of REALPTR is
identical to a standard pointer as used in real mode.  The 
REALPTR data type is used when mixing real and protected mode
code in the same program.  A REALPTR cannot be dereferenced
in protected mode since the format of pointers in real and
protected mode are different.

As well as the data definition for the REALPTR type, the following
macros are available to set and extract the segment and
offset fields of a REALPR.  The RP_OFF macro returns the offset
portion of a REALPTR.  The RP_SEG macro returns the segment portion
of a REALPTR.  The macro RP_SET is used to combine a segment and an
offset into a REALPTR.  It takes three arguments: the name of the 
REALPTR to be set, an offset, and a segment number.

*/

typedef ULONG REALPTR;

#define RP_OFF(rp) ((USHORT)(((ULONG)(rp)) & 0xFFFF))
#define RP_SEG(rp) ((USHORT)(((ULONG)(rp)) >> 16))
#define RP_SET(rp, off, seg) (rp = ((ULONG)(seg) << 16) + (off))


/*

Far pointer data type (selector:offset32)

The MetaWare 80386 High C compiler supports far pointers as well as
32-bit near pointers.  A far pointer consists of a 32-bit offset followed
by 16-bit selector number.  Far pointers are used to reference memory
locations in segments outside of the data segment.  In the MetaWare
High C compiler a far pointer is declared using a definition of the
following form:

	char _far *ptr;

The "_far" keyword is used to indicate a pointer is a far pointer as 
opposed to a near pointer.  Note: For compatibility with existing C 
source code which is compiled with the 8086 Microsoft C compiler
C code, Microsoft C "far" keyword can still used by putting the
following #define in a header file:

	#define far _far

The following macros are used to get and set the selector and offset fields
of far pointers.  The FP_SEL macro returns the 16-bit selector number field
of a far pointer.  The FP_OFF macro returns the 32-bit offset
field of a far pointer.  The FP_SET macro is used to construct a far
pointer from a selector number and offset.  It takes three arguments:
the name of the far pointer to be set, an offset, and a selector number.

*/

typedef UCHAR _far *FARPTR;

#ifndef FP_SEL
#define FP_SEL(fp) ((USHORT)(*(((USHORT *)&(fp))+sizeof(UINT)/sizeof(USHORT))))
#endif

#ifndef FP_OFF
#define FP_OFF(fp) ((UINT)(*(UCHAR **)&(fp)))
#endif

#ifndef FP_SET
#define FP_SET(fp, off, sel) ((*(UINT *)&fp=(UINT)(off)),\
(*(((USHORT *)&fp) + sizeof(UINT)/sizeof(USHORT))=sel))
#endif

#endif
