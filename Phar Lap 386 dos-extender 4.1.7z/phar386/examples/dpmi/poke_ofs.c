/* 
POKE_OFS.C -- poke video display memory one million  
times, using Phar Lap Map Physical Memory at End of 
Segment (INT 21h AX=250Ah) call

MetaWare High C: hc386 poke_ofs.c
*/ 
 
#include <stdlib.h> 
#include <stdio.h> 
#include <string.h>
#include <dos.h> 
#include <time.h> 
#include "rmint86.h"    // just for WATCOMC union REGS defines 
 
#define MAX 1000000 
 
/* Returns NEAR pointer to mapped memory */ 
void *map_phys(unsigned baseaddr, unsigned numpages) 
{ 
    union REGS r; 
    struct SREGS s; 
    memset(&r, 0, sizeof(r)); 
    segread(&s); 
    s.es = s.ds; 
    r.x.ax = 0x250a; 
    r.x.bx = baseaddr; 
    r.x.cx = numpages; 
    intdosx(&r, &r, &s); 
    return (void *) ((r.x.cflag) ? 0 : r.x.ax); 
} 
 
void fail(char *s) { puts(s); exit(1); } 
 
main() 
{ 
    unsigned short *p;  /* NEAR pointer */ 
    time_t t1, t2; 
    unsigned i; 
     
    if (! (p = map_phys(0xb8000, 1))) /* map 4k at b800:0000 */ 
        fail("can't map physical memory"); 
    time(&t1); 
    for (i=MAX; i--; ) 
        p[i%2000] = i; 
    time(&t2); 
    printf("%u POKE_OFS/second (%u seconds)\n",  
        MAX/(t2-t1), t2-t1); 
    return 0; 
} 
 
