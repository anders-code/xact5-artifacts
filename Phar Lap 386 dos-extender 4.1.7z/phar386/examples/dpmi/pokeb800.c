/* 
POKEB800.C -- poke video display memory 1 million times

MetaWare High C: hc386 pokeb800.c
*/ 
 
#include <stdlib.h> 
#include <stdio.h> 
#include <dos.h> 
#include <time.h> 
 
/* Construct a 48 bit selector:offset far pointer */ 
#ifdef __WATCOMC__ 
/* Watcom C DOS.H comes with pragma aux MK_FP */ 
#define MK_FARPTR(fp, s, o) \
    (fp) = MK_FP((s), (o)) 
#else 
/* MetaWare High C */ 
typedef struct { unsigned ofs; short sel; } selofs; 
typedef union { void _far *fp; selofs so; } farptr; 
#define MK_FARPTR(fp, s, o) { \
    ((farptr *) (&(fp)))->so.sel = s; \
    ((farptr *) (&(fp)))->so.ofs = o; \
    } 
#endif 
 
#define MAX 1000000 
 
main()
{ 
    unsigned short _far *fp; 
    time_t t1, t2; 
    unsigned i; 
 
/*  Either of the following techniques will work. */     
#if 1 
/*  Selector 1Ch maps physical memory for the screen, and is 
    automatically updated by 386|DOS Extender any time the 
    BIOS Set Video Mode call (INT 10h AH=0) call is made. */ 
 
    MK_FARPTR(fp, 0x1c, 0); 
#else 
/*  Selector 34h maps the entire first megabyte of memory:   
    real mode pointers such as B800:0000 become offsets into 
    this large 32 bit segment. */ 
#define MK_P (fp, s, o)  MK_FARPTR(fp, 0x34, (s)<<4+(o)) 
 
    MK_P(fp, 0x34, 0xb800, 0); 
#endif 
 
    time(&t1); 
    for (i=MAX; i--; ) 
        fp [i%2000] = i; 
    time(&t2); 
    printf("%u POKEB800/second (%u seconds)\n",  
        MAX/(t2-t1), t2-t1); 
    return 0; 
} 
