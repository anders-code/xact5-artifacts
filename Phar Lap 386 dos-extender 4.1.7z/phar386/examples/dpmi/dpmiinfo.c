/* 
DPMIINFO.C

MetaWare High C: hc386 -I\pharlap\includes dpmiinfo.c -l\pharlap\libs\dosx32.lib

Watcom C/386: wcl386 -3r dpmiinfo.c
*/ 
 
#include <stdlib.h> 
#include <stdio.h> 
#include <string.h>
#include <dos.h>
#include "pharlap.h"    // in 386dosx \INCLUDES 
 
#ifdef __WATCOMC__ 
#define CLEAR(x)        memset(&x, 0, sizeof(x))

extern int _dx_config_inf(CONFIG_INF *bufp, UCHAR *swf_namep)
{
    union REGS r;
    struct SREGS s;
    CLEAR(r);
    r.x.eax = 0x2526;
    segread(&s);
    r.x.ebx = (unsigned) bufp;
    r.x.ecx = (unsigned) swf_namep;
    intdosx(&r, &r, &s);
    return 1;
}
#endif 
 
void fail(char *s) { puts(s); exit(1); } 
 
main() 
{ 
    CONFIG_INF config; 
    UCHAR vmmname[256]; 
     
    _dx_config_inf(&config, vmmname); 
     
    printf("386|DOS Extender v. %u.%u\n",  
        config.c_major, config.c_minor); 
 
    if (! config.c_dpmif) 
        fail("DPMI is not present"); 
     
    printf("DPMI v. %u.%u\n",  
        config.c_dpmimaj, config.c_dpmimin); 
     
    if (config.c_dpmi_capf & 1) 
        puts("DPMI Paging Support capability"); 
    if (config.c_dpmi_capf & 2) 
        puts("DPMI Device Mapping capability"); 
    if (config.c_dpmi_capf & 4) 
        puts("DPMI Conventional Memory capability"); 
    if (config.c_dpmi_capf & 8) 
        puts("DPMI Exception Restartability capability"); 
    if (config.c_dpmi_capf & 16) 
        puts("DPMI Page Accessed/Dirty capability"); 
     
    return 0; 
} 
