/* 
DMA.C -- uses Virtual DMA Services (VDS)

sample output:
DMA Services 1.0
Maximum DMA buffer: 196864 bytes
Automatic remap not supported
All memory not physically contiguous

MetaWare High C: hc386 dma.c rmint86.obj

Watcom C/386: wcl386 -3r dma.c rmint86.obj
*/ 
 
#include <stdlib.h> 
#include <stdio.h> 
#include <string.h>
#include <dos.h> 
#include "rmint86.h" 
 
#define CLEAR(x)        memset(&x, 0, sizeof(x)) 
 
#ifdef __WATCOMC__ 
#define MK_FARPTR(fp, s, o) \
    (fp) = MK_FP((s), (o)) 
#else 
#define far _far 
/* MetaWare High C */ 
typedef struct { unsigned ofs; short sel; } selofs; 
typedef union { void far *fp; selofs so; } farptr; 
#define MK_FARPTR(fp, s, o) { \
    ((farptr *) (&(fp)))->so.sel = s; \
    ((farptr *) (&(fp)))->so.ofs = o; \
    } 
#endif 
 
typedef struct { 
    unsigned long size; 
    unsigned long linear_ofs; 
    unsigned short seg; 
    unsigned short buff_id; 
    unsigned long phys_addr; 
    } DDS;  /* DMA descriptor structure */ 
 
void fail(char *s) { puts(s); exit(1); } 
 
int lin_eq_phys(void)   // is linear==physical? 
{ 
    unsigned char far *bios; 
    MK_FARPTR(bios, 0x34, 0x400L);  // use selector 34h 
    return (! bios[0x7b] & 0x20);   // check 0040:007B 
} 
 
int vds_get_version(unsigned *pmaj, unsigned *pmin,  
                    unsigned *pmaxbuff, unsigned *pfeatures) 
{ 
    union REGS r; 
    CLEAR(r); 
    r.h.ah = 0x81; 
    r.h.al = 0x02; 
    r.x.dx = 0; 
    rm_int86(0x4b, &r, &r);   // VDS uses INT 4Bh 
    if (r.x.cflag) 
        return 0;   // VDS Get Version failed 
    *pmaj = r.h.ah; 
    *pmin = r.h.al; 
    *pmaxbuff = (r.x.bx << 16) + r.x.cx; 
    *pfeatures = r.x.dx; 
    return 1; 
} 
     
main() 
{ 
    unsigned maj, min, maxbuff, features; 
     
    if (lin_eq_phys()) 
        fail("linear == physical"); // no VDS 
             
    if (! vds_get_version(&maj, &min, &maxbuff, &features)) 
        fail("VDS Get Version failed"); 
    
    // possibly check maj/min for reasonableness
     
    printf("DMA Services %d.%d\n", maj, min); 
    printf("Maximum DMA buffer: %u bytes\n", maxbuff); 
    if (features & 1) puts("PC/XT bus architecture (first meg only"); 
    if (features & 2) puts("Physical buffer/remap region in first meg"); 
    if (features & 4) puts("Automatic remap supported"); 
    else              puts("Automatic remap not supported"); 
    if (features & 8) puts("All memory physically contiguous"); 
    else              puts("All memory not physically contiguous"); 
     
    return 0; 
} 
