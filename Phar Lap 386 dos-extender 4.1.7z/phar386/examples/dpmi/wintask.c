/* 
WINTASK.C
*/ 
 
#include <stdlib.h> 
#include <string.h>
#include <dos.h> 
#include "rmint86.h" 
#include "wintask.h" 
 
#define CLEAR(x)    memset(&x, 0, sizeof(x)) 
 
unsigned VMId(void) 
{ 
    union REGS r; 
    CLEAR(r); 
    r.x.ax = 0x1683; 
    rm_int86(0x2f, &r, &r); 
    return r.x.bx;  // VM# returned in BX 
} 
 
void BeginCriticalSection(void) 
{ 
    union REGS r; 
    CLEAR(r); 
    r.x.ax = 0x1681; 
    rm_int86(0x2f, &r, &r); 
} 
 
void EndCriticalSection(void) 
{ 
    union REGS r; 
    CLEAR(r); 
    r.x.ax = 0x1682; 
    rm_int86(0x2f, &r, &r); 
} 
