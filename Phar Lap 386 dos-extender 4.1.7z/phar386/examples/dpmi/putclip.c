/* 
PUTCLIP.C -- put text on Windows clipboard

MetaWare High C: hc386 putclip.c winclip.obj rmint86.obj
Watcom C/386: wcl386 -3r putclip.c winclip.obj rmint86.obj
*/ 
 
#include <stdlib.h> 
#include <stdio.h> 
#include <string.h> 
#include <dos.h> 
#include <io.h> 
#include <fcntl.h> 
#include "winclip.h" 
 
void fail(char *s) { puts(s); exit(1); } 
 
int main(int argc, char *argv[]) 
{ 
    int f, len, maj, min; 
    unsigned rc; // number of bytes read 
    char *p; 
 
    if (! WinOldApVersion(&maj, &min)) 
      fail("This program requires Windows Enhanced mode"); 
 
    if (argc < 2) 
        fail("usage: putclip [filename]"); 
     
    if (_dos_open(argv[1], O_RDONLY, &f) != 0) 
        fail("can't open file"); 
    len = filelength(f); 
    if ((p = malloc(len+1)) == 0) 
        fail("insufficient memory"); 
    if (_dos_read(f, p, len, &rc) != 0) 
        fail("can't read file"); 
    _dos_close(f); 
    p[rc] = '\0';  // must be NULL terminated 
     
    fputs("putclip ", stdout); 
    switch (PutClipStrLen(p, rc+1)) // include space for NULL 
    { 
        case 0:   puts("failed"); break; 
        case 1:   puts("successful"); break; 
        case -1:  puts("requires Windows Enhanced mode"); break; 
    } 
    free(p); 
    return 0; 
} 
