/* 
INTERUPT.C -- generate one million interrupts -- real mode program

Microsoft C: cl interupt.c
Borland C++: bcc interupt.c
*/ 
 
#include <stdlib.h> 
#include <stdio.h> 
#include <dos.h> 
#include <time.h> 
 
#define MAX 1000000 
 
void interrupt far int63() { return; }  /* empty handler */ 
 
main() 
{ 
    unsigned long i; 
    void (interrupt far *old63)(); 
    time_t t1, t2; 
    old63 = _dos_getvect(0x63); 
    _dos_setvect(0x63, int63); 
    time(&t1); 
    for (i=MAX; i--; ) 
        _asm int 63h 
    time(&t2); 
    _dos_setvect(0x63, old63); 
    printf("%lu INT/second (%lu seconds)\n",  
        MAX/(t2-t1), t2-t1); 
} 
