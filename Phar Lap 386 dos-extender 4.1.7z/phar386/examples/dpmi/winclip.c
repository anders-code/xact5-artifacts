/* 
WINCLIP.C -- Windows Clipboard access -- implementation 
386|DOS Extender functions for Windows 3.x (Enhanced) 
Clipboard 
*/ 
 
#include <stdlib.h> 
#include <stdio.h> 
#include <malloc.h> 
#include <string.h> 
#include <dos.h> 
#include "rmint86.h" 
#include "winclip.h" 
 
#ifndef __WATCOMC__ 
// MetaWare High C doesn't have _fmemcpy 
void _fmemcpy(unsigned char far *dest, unsigned char far *src, int len) 
{ 
    int i; 
    unsigned char far *d; 
    unsigned char far *s; 
    for (i=len, d=dest, s=src; i--; d++, s++) 
        *d = *s; 
} 
#endif 
 
static int clip_open=0; 
static int do_convert=1; 
 
/**************************************************************/ 
 
int PutClipStrLen(char *s, unsigned len) 
{ 
    int maj, min; 
    int ret = 0; 
    char *buf, *s2; 
    unsigned len2; 
     
    if (! WinOldApVersion(&maj, &min)) 
        return  1;  // Windows Enhanced mode isn't running 
 
    // change all 0d 0a to 0a 
    if (do_convert) 
    { 
        if (! (buf = calloc(len, 1))) 
            return 0;   // insufficient memory 
        for (s2=buf, len2=len; len2--; s2++, s++) 
        { 
            if ((s[0] == 0x0d) && (s[1] == 0x0a)) 
            { 
                s++; 
                len--;      // remove 0d 
            } 
            *s2 = *s; 
        } 
    } 
    else 
        buf=s; 
         
    if (! OpenClipboard()) 
        return 0; 
    clip_open++; 
    /* note: if calling program dies between OpenClipboard and 
       CloseClipboard, then no other program can access it until 
       Windows has been restarted. Perhaps put CloseClipboard() 
       call into ctrl-c handler */ 
    EmptyClipboard(); 
    if (CompactClipboard(len) < len) 
        puts("couldn't compact clipboard"); 
    else 
        ret = SetClipboardData(buf, CF_TEXT, len); 
    CloseClipboard(); 
    clip_open--; 
    free(buf); 
    return ret? 1 : 0; 
} 
 
int PutClipString(char *s) 
{ 
    return PutClipStrLen(s, strlen(s)+1); 
} 
 
char *GetClipString(void) 
{ 
    char *s; 
    unsigned char far *data; 
    int maj, min; 
    unsigned long len; 
     
    if (! WinOldApVersion(&maj, &min)) 
        return 0; 
    if (! OpenClipboard()) 
        return (char *)0; 
    if ((len = GetClipboardSize(CF_TEXT)) == 0) 
    { 
        CloseClipboard(); 
        return NULL; 
    } 
    if ((s = malloc(len+1)) == NULL) // add one for ASCIIZ 
        return NULL; 
    data = GetClipboardData(CF_TEXT); 
    _fmemcpy(s, data, len); 
    CloseClipboard();                   // important!! 
    FreeClipboardData(data);            // in conv mem buffer 
    s[len] = '\0';                      // make ASCIIZ 
    return s; 
} 
 
void FreeClipString(char *s) 
{ 
    free(s); 
} 
 
/**************************************************************/ 
 
/* INT 2Fh old application clipboard functions */ 
#define MPLEX           0x2f 
#define WINOLDAP_VERS   0x1700 
#define OPEN_CLIP       0x1701 
#define EMPTY_CLIP      0x1702 
#define SET_CLIP_DATA   0x1703 
#define GET_CLIP_SIZE   0x1704 
#define GET_CLIP_DATA   0x1705 
#define CLOSE_CLIP      0x1708 
#define CLIP_COMPACT    0x1709 
#define GET_DEV_CAPS    0x170A 
 
#ifndef MAKELONG         
#define MAKELONG(a, b)  ((long)(((unsigned)(a)) | \
    ((unsigned long)((unsigned)(b))) << 16)) 
#endif 
 
#define LO(x)           ((x) & 0xFF) 
#define HI(x)           ((x) >> 8) 
#define CLEAR(x)        memset(&x, 0, sizeof(x)) 
#ifndef FALSE 
#define FALSE 0 
#define TRUE  1 
#endif 
 
#ifdef __WATCOMC__ 
#define MK_FARPTR(fp, s, o) \ 
    (fp) = MK_FP((s), (o)) 
#else 
/* MetaWare High C */ 
typedef struct { unsigned ofs; short sel; } selofs; 
typedef union { void far *fp; selofs so; } farptr; 
#define MK_FARPTR(fp, s, o) { \
    ((farptr *) (&(fp)))->so.sel = s; \
    ((farptr *) (&(fp)))->so.ofs = o; \
    } 
#endif 
 
int WinOldApVersion(int *maj, int *min) 
{ 
    union REGS r; 
    unsigned ret; 
    CLEAR(r); 
    r.x.ax = WINOLDAP_VERS; 
    rm_int86(MPLEX, &r, &r); 
    if ((ret = r.x.ax) == WINOLDAP_VERS) // didn't change 
        return FALSE; 
    else 
    { 
        *maj = LO(ret); 
        *min = HI(ret); 
        return TRUE; 
    } 
} 
 
int OpenClipboard(void) 
{ 
    union REGS r; 
    CLEAR(r); 
    r.x.ax = OPEN_CLIP; 
    rm_int86(MPLEX, &r, &r); 
    return r.x.ax; 
} 
 
void EmptyClipboard(void) 
{ 
    union REGS r; 
    CLEAR(r); 
    r.x.ax = EMPTY_CLIP; 
    rm_int86(MPLEX, &r, &r); 
} 
 
int SetClipboardData(unsigned char far *data, CF_FORMAT format,  
    unsigned long size) 
{ 
    union REGS r; 
    struct SREGS s; 
    unsigned char far *fp; 
    unsigned addr; 
     
    CLEAR(r); 
    CLEAR(s); 
 
    // allocate conventional memory, keep real mode seg addr 
    if ((addr = alloc_conventional(1 + (size >> 4))) == 0) 
        return 0; 
     
    // poke data into conv. mem. buffer using prot mode selector 
    MK_FARPTR(fp, 0x34, addr << 4); 
    _fmemcpy(fp, data, size); 
     
    // pass the real mode address to the SET_CLIP_DATA function 
    s.es = addr; 
    r.x.bx = 0; 
    r.x.ax = SET_CLIP_DATA; 
    r.x.dx = format; 
    r.x.si = size >> 16; 
    r.x.cx = size & 0xFFFF; 
 
    rm_int86x(MPLEX, &r, &r, &s); 
    free_conventional(addr); 
    return (r.x.ax != 0); 
} 
 
unsigned long GetClipboardSize(CF_FORMAT format) 
{ 
    union REGS r; 
    CLEAR(r); 
    r.x.ax = GET_CLIP_SIZE; 
    r.x.dx = format; 
    rm_int86(MPLEX, &r, &r); 
    return MAKELONG(r.x.ax, r.x.dx); 
} 
 
unsigned char far *GetClipboardData(CF_FORMAT format) 
{ 
    union REGS r; 
    struct SREGS s; 
    unsigned char far *fp; 
    unsigned long size; 
    unsigned addr; 
     
    CLEAR(r); 
    CLEAR(s); 
     
    size = GetClipboardSize(format); 
 
    // allocate conv. memory, keep real mode segment address 
    if ((addr = alloc_conventional(1 + (size >> 4))) == 0) 
        return 0; 
     
    // pass the real mode address to the GET_CLIP_DATA function 
    s.es = addr; 
    r.x.bx = 0; 
    r.x.ax = GET_CLIP_DATA; 
    r.x.dx = format; 
    rm_int86x(MPLEX, &r, &r, &s); 
 
    // return prot mode selector to conventional memory buffer 
    MK_FARPTR(fp, 0x34, addr << 4); 
    return fp; 
} 
 
void FreeClipboardData(unsigned char far *buf) 
{ 
    free_conventional(FP_SEG(buf)); 
} 
 
void CloseClipboard(void) 
{ 
    union REGS r; 
    CLEAR(r); 
    r.x.ax = CLOSE_CLIP; 
    rm_int86(MPLEX, &r, &r); 
} 
 
unsigned long CompactClipboard(unsigned long desire) 
{ 
    union REGS r; 
    CLEAR(r); 
    r.x.ax = CLIP_COMPACT; 
    r.x.si = desire >> 16; 
    r.x.cx = desire & 0xFFFF; 
    rm_int86(MPLEX, &r, &r); 
    return MAKELONG(r.x.ax, r.x.dx); 
} 
 
unsigned GetDeviceCaps(unsigned cap) 
{ 
    union REGS r; 
    CLEAR(r); 
    r.x.ax = GET_DEV_CAPS; 
    r.x.dx = cap; 
    rm_int86(MPLEX, &r, &r); 
    return r.x.ax; 
} 
