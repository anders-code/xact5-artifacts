/* 
TASKTEST.C

MetaWare High C: hc386 tasktest.c iswin3e.c wintask.obj yield.obj rmint86.obj
Watcom C/386: wcl386 -3r tasktest.c iswin3e.c wintask.obj yield.obj rmint86.obj
*/ 
 
#include <stdlib.h> 
#include <stdio.h> 
#include <time.h> 
#include "wintask.h" 
 
#ifdef __WATCOMC__ 
#pragma aux EXTERN "*"; 
#pragma aux (EXTERN) Yield; 
#endif 
 
extern void Yield(void); // YIELD.ASM 
 
void wait(unsigned seconds) 
{ 
    time_t t1, t2; 
    time(&t1); 
    while ((time(&t2)-t1) < seconds) 
        Yield(); 
} 
 
void fail(char *s) { puts(s); exit(1); } 
 
extern int win3e(int *pmaj, int *pmin);  // see ISWIN3E.C 
 
main() 
{ 
    int dummy; 
    if (! win3e(&dummy, &dummy)) 
        fail("This program requires Windows 3.0 Enhanced mode"); 
    printf("VM Id: %u\n", VMId()); 
    wait(5);  // give user chance to switch to other task 
    fputs("Try to do something...", stdout); 
    fflush(stdout); 
    Yield();  // Yield so task that produces output gets to run! 
    BeginCriticalSection(); 
    /* No other Windows tasks can run; also can't switch  
       away with mouse or ALT ESC or CTRL ESC! */ 
    wait(5); 
    EndCriticalSection(); 
    /* Now other tasks can run; can also switch away again */ 
    puts("done"); 
    return 0; 
} 
