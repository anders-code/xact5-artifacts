/*  
RMINT86.C -- rm_int86() and rm_int86x() -- implementation 
Real mode interrupts from 386|DOS Extender 
Also contains alloc_conventional(), free_conventional() 
*/ 
 
#include <stdlib.h> 
#include <stdio.h> 
#include <string.h> 
#include <dos.h> 
#include "rmint86.h" 
 
typedef struct { 
    unsigned short intno, ds, es, fs, gs; 
    unsigned eax, edx; 
    } RMODE_PARAM_BLOCK; 
     
#define RMODE_INTER     0x2511 
 
#define CLEAR(x)        memset(&x, 0, sizeof(x)) 
 
unsigned rm_int86(int intno, union REGS *in, union REGS *out) 
{ 
    RMODE_PARAM_BLOCK rpb; 
    unsigned ret; 
    CLEAR(rpb); 
    rpb.intno = intno; 
    rpb.eax = in->x.ax; 
    rpb.edx = in->x.dx; 
    in->x.ax = RMODE_INTER; 
    in->x.dx = (unsigned) &rpb; 
    ret = intdos(in, out); 
    out->x.dx = rpb.edx; 
    return ret; 
} 
 
unsigned rm_int86x(int intno, union REGS *in, union REGS *out, 
    struct SREGS *sregs) 
{ 
    RMODE_PARAM_BLOCK rpb; 
    unsigned ret; 
    CLEAR(rpb); 
    rpb.intno = intno; 
    rpb.eax = in->x.ax; 
    rpb.edx = in->x.dx; 
    rpb.ds = sregs->ds; 
    rpb.es = sregs->es; 
    rpb.fs = rpb.gs = 0; 
    in->x.ax = RMODE_INTER; 
    in->x.dx = (unsigned) &rpb; 
    ret = intdos(in, out); 
    out->x.dx = rpb.edx; 
    sregs->ds = rpb.ds; 
    sregs->es = rpb.es; 
    return ret; 
} 
 
#define CONV_ALLOC      0x25C0 
#define CONV_FREE       0x25C1 
 
unsigned alloc_conventional(unsigned para) 
{ 
    union REGS r; 
    CLEAR (r); 
    r.x.ax = CONV_ALLOC; 
    r.x.bx = para; 
    intdos(&r, &r); 
    return (r.x.cflag) ? 0 : r.x.ax; 
} 
 
unsigned free_conventional(unsigned addr) 
{ 
    union REGS r; 
    CLEAR (r); 
    r.x.ax = CONV_FREE; 
    r.x.cx = addr; 
    intdos(&r, &r); 
    return (r.x.cflag == 0); 
} 
