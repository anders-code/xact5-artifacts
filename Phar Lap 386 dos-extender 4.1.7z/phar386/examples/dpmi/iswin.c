/*  
ISWIN.C  
Based on Microsoft Systems Journal, March 1991, p. 117 

MetaWare High C: hc386 iswin.c rmint86.obj
Watcom C/386: wcl386 -3r iswin.c rmint86.obj
*/ 
 
#include <stdlib.h> 
#include <stdio.h> 
#include <string.h> 
#include <dos.h> 
#include "rmint86.h" 
 
int windows(int *pv1, int *pv2); 
 
main() 
{ 
    int v1, v2; 
     
    if (! windows(&v1, &v2)) 
        puts("Windows is not running"); 
    else 
        switch (v1) 
        { 
            case 0x01: 
            case 0x7f: 
                puts("Windows/386 2.x"); 
                break; 
            case 0x80: 
                puts("Windows 3.x Real mode"); 
                break; 
            case 0xFF: 
                puts("Windows 3.x Standard mode"); 
                break; 
            default: 
                printf("Windows %d.%d Enhanced mode\n", v1, v2); 
        } 
    return 0; 
} 
 
int windows(int *pv1, int *pv2) 
{ 
    union REGS r; 
    struct SREGS s; 
  
    memset(&r, 0, sizeof(r)); 
    r.x.ax = 0x4680;        /* Real and Standard check */ 
    rm_int86(0x2f, &r, &r); 
    /* r.h.al will be 0x80 or 0 at this point */ 
    r.h.cl = r.h.al ^ 0x80; 
    r.x.ax = 0x1600;        /* Enhanced check */ 
    rm_int86(0x2f, &r, &r); 
    /* r.h.al will be 0, 0x80, 0x01, 0xFF, or 0x0? */ 
    r.h.al &= 0x7F; 
    r.h.al |= r.h.cl; 
    if (r.h.al == 0x80)      
    { 
        r.x.ax = 0x1605; 
        r.x.bx = s.es = 0; 
        r.x.si = s.ds = 0; 
        r.x.cx = 0; 
        r.x.dx = 1; /* Windows Standard mode DOSX */ 
        rm_int86x(0x2f, &r, &r, &s); 
        /* r.x.cx will be 0 or 0xFFFF at this point */ 
        if (r.x.cx == 0) 
        { 
            r.x.ax = 0x1606;    /* Standard/Enhanced exit */ 
            rm_int86x(0x2f, &r, &r, &s); 
        } 
        r.h.al = r.h.cl | 0x80; 
    } 
    *pv1 = r.h.al; 
    *pv2 = r.h.ah; 
    return (r.h.al) ? 1 : 0; 
} 
