/* 
MEMAVAIL.C -- illustrates Windows 3.0 grow limit

C:\DOSX386>run386 memavail
Memory available: 2061312 bytes

C:\DOSX386>run386 -win30limit +300000h memavail
Memory available: 3093504 bytes

MetaWare High C: hc386 memavail.c
*/ 
 
#include <stdlib.h> 
#include <stdio.h> 
 
#define BLKSIZE     1024 
 
main() 
{ 
    char *p; 
    unsigned bytes=0;   // 32 bits 
    while ((p = malloc(BLKSIZE)) != 0) 
    { 
        *p = 'x'; // touch  
        p[BLKSIZE-1] = 'y'; 
        bytes += BLKSIZE; 
    } 
    printf("Memory available: %u bytes\n", bytes); 
    return 0; 
} 
