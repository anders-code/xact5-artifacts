/* 
IDLE.C

MetaWare High C: hc386 idle.c yield.obj
Watcom C/386: wcl386 -3r idle.c yield.obj
*/ 
 
#include <stdlib.h> 
#include <stdio.h> 
#include <conio.h> 
#include <time.h> 
 
#ifdef __WATCOMC__ 
#pragma aux EXTERN "*"; 
#pragma aux (EXTERN) Yield; 
#endif 
 
extern void Yield(void); // YIELD.ASM 
 
main(int argc, char *argv[]) 
{ 
    time_t t1, t2; 
    unsigned long iter = 0; 
    int do_yield = (argc > 1) ? 1 : 0; 
     
    time(&t1); 
    while (! kbhit()) 
    { 
        if (do_yield) 
            Yield(); 
        iter++; 
        if ((time(&t2)-t1) >= 60) 
            break; 
    } 
    time(&t2); 
     
    printf("%lu iterations in %lu seconds\n", iter, t2-t1); 
    return 0; 
} 
