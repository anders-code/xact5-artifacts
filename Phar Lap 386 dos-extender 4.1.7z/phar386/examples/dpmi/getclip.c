/* 
GETCLIP.C -- get text from Windows clipboard

MetaWare High C: hc386 getclip.c winclip.obj rmint86.obj
Watcom C/386: wcl386 -3r getclip.c winclip.obj rmint86.obj
*/ 
 
#include <stdlib.h> 
#include <stdio.h> 
#include <string.h> 
#include "winclip.h" 
 
void fail(char *s) { puts(s); exit(1); } 
 
int main(void) 
{ 
    char *s; 
    int maj, min; 
     
    if (! WinOldApVersion(&maj, &min)) 
        fail("This program requires Windows Enhanced mode"); 
 
    if ((s = GetClipString()) != NULL)
    { 
        puts(s); 
        FreeClipString(s); 
    } 
    
    return 0;
} 
