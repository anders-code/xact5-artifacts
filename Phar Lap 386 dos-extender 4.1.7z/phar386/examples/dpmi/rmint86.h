/*  
RMINT86.H -- rm_int86() and rm_int86x() -- definition 
Must be included after DOS.H. 
Real mode interrupts from 386|DOS Extender 
Also defines alloc_conventional(), free_conventional() 
*/ 
 
#ifdef __WATCOMC__ 
// Watcom C union REGS field names are nonstandard 
#define ax              eax 
#define bx              ebx 
#define cx              ecx 
#define dx              edx 
#define si              esi 
#define di              edi 
#define int86(x,y,z)	int386(x,y,z)
#define int86x(x,y,z,a) int386x(x,y,z,a)
#endif 
 
extern unsigned rm_int86(int intno, union REGS *in, union REGS *out); 
extern unsigned rm_int86x(int intno, union REGS *in, union REGS *out, 
    struct SREGS *sregs); 
 
extern unsigned alloc_conventional(unsigned para); 
extern unsigned free_conventional(unsigned addr); 
