/* 
ISWIN3E.C

MetaWare High C: hc386 -DTESTING iswin3e.c rmint86.obj
Watcom C/386: wcl386 -DTESTING -3r iswin3e.c rmint86.obj
*/
 
#include <stdlib.h> 
#include <stdio.h> 
#include <string.h> 
#include <dos.h> 
#include "rmint86.h" 
 
int win3e(int *pmaj, int *pmin) 
{ 
   union REGS r; 
     
   memset(&r, 0, sizeof(r)); 
   r.x.ax = 0x1600; 
   rm_int86(0x2f, &r, &r); 
   *pmaj = r.h.al; 
   *pmin = r.h.ah; 
   return (r.h.al > 1 && r.h.al != 0x80); 
} 

#ifdef TESTING
main() 
{ 
   int maj, min; 
   if (! win3e(&maj, &min)) 
      printf("Not running under Windows 3.x Enhanced mode\n"); 
   else 
      printf("Running under Windows %d.%d Enhanced mode\n",  
            maj, min); 
   return 0; 
} 
#endif
