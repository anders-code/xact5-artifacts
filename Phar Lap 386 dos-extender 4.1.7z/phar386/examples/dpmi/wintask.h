/* WINTASK.H */ 
 
unsigned VMId(void); 
void BeginCriticalSection(void); 
void EndCriticalSection(void); 
void Yield(void);   // in YIELD.ASM 
