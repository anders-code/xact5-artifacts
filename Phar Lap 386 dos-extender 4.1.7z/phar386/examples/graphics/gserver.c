/* gserver.c - Graphics server code */

/************************************************************************/
/*	Copyright (C) 1986-1988 Phar Lap Software, Inc.			*/
/*	Unpublished - rights reserved under the Copyright Laws of the	*/
/*	United States.  Use, duplication, or disclosure by the 		*/
/*	Government is subject to restrictions as set forth in 		*/
/*	subparagraph (c)(1)(ii) of the Rights in Technical Data and 	*/
/*	Computer Software clause at 252.227-7013.			*/
/*	Phar Lap Software, Inc., 60 Aberdeen Ave., Cambridge, MA 02138	*/
/************************************************************************/

/*
 * This is real mode code which must be compiled in large model.  We
 * have to be compiled in large model so that all pointers are FAR
 * pointers.
 */

#include <stdio.h>
#include <stdlib.h>

#include "graph.h"
#include "gserver.h"

/*

main - Main routine for the real mode graphics server

*/

main()

{

	extern void gserver();

	/* Print out a message on the screen telling that we were loaded
	   okay */

	flushall();
	printf("C run-time library -- Copyright (C) 1987 Microsoft, Inc.\n");
	printf("Real mode graphics server has initialized.\n");
	flushall();

	/* Return to protected mode */

	protret();
}


/*

gserver - Graphics server

*/

void gserver(bp)

char *bp;		/* Pointer to the communications buffer
			   passed in by the protected mode code */

{

	char *ebp;		/* End of buffer pointer */
	unsigned int len;	/* Length of the current command */
	struct xycoord xy;	/* X-Y co-ordinates */
	struct rccoord rc;	/* Row-column co-ordinates */
	struct videoconfig vc;	/* Video configuration */

	/* The first short in the communications buffer gives the number
	   of bytes used for graphics commands in the buffer.  From this
	   count, calculate "ebp" which point to the first byte after the
	   last command in the buffer. */

	ebp = bp + SHORT0;
	bp += sizeof(short);

	/* Loop through the buffer and execute each graphics command. */

	while(bp < ebp)
	{

		/* Decode the current graphics command */

		switch(*bp++)
		{

			/* Command executors */

			case op_arc:
				*SHORT16P = _arc(SHORT0, SHORT2, SHORT4,
				            SHORT6, SHORT8, SHORT10, SHORT12,
				            SHORT14);
				len = sizeof(short) * 9;
				break;

			case op_clearscreen:
				_clearscreen(SHORT0);
				len = sizeof(short);
				break;

			case op_displaycursor:
				*SHORT2P = _displaycursor(SHORT0);
				len = sizeof(short) * 2;
				break;

			case op_ellipse:
				*SHORT10P = _ellipse(SHORT0, SHORT2, SHORT4,
				            SHORT6, SHORT8);
				len = sizeof(short) * 6;
				break;

			case op_floodfill:
				*SHORT6P = _floodfill(SHORT0, SHORT2, SHORT4);
				len = sizeof(short) * 4;
				break;

			case op_getbkcolor:
				*LONG0P = _getbkcolor();
				len = sizeof(long);
				break;

			case op_getcolor:
				*SHORT0P = _getcolor();
				len = sizeof(short);
				break;

			case op_getcurrentposition:
				xy = _getcurrentposition();
				*SHORT0P = xy.xcoord;
				*SHORT2P = xy.ycoord;
				len = sizeof(short) * 2;
				break;

			case op_getfillmask:
				*SHORT8P = _getfillmask(bp) != NULL;
				len = sizeof(short) + 8;
				break;

			case op_getlinestyle:
				*SHORT0P = _getlinestyle();
				len = sizeof(short);
				break;

			case op_getlogcoord:
				xy = _getlogcoord(SHORT0, SHORT2);
				*SHORT4P = xy.xcoord;
				*SHORT6P = xy.ycoord;
				len = sizeof(short) * 4;
				break;

			case op_getphyscoord:
				xy = _getphyscoord(SHORT0, SHORT2);
				*SHORT4P = xy.xcoord;
				*SHORT6P = xy.ycoord;
				len = sizeof(short) * 4;
				break;

			case op_getpixel:
				*SHORT4P = _getpixel(SHORT0, SHORT2);
				len = sizeof(short) * 3;
				break;

			case op_gettextcolor:
				*SHORT0P = _gettextcolor();
				len = sizeof(short);
				break;

			case op_gettextposition:
				rc = _gettextposition();
				*SHORT0P = rc.row;
				*SHORT2P = rc.col;
				len = sizeof(short) * 2;
				break;

			case op_getvideoconfig:
				_getvideoconfig(&vc);
				*SHORT0P = vc.numxpixels;
				*SHORT2P = vc.numypixels;
				*SHORT4P = vc.numtextcols;
				*SHORT6P = vc.numtextrows;
				*SHORT8P = vc.numcolors;
				*SHORT10P = vc.bitsperpixel;
				*SHORT12P = vc.numvideopages;
				*SHORT14P = vc.mode;
				*SHORT16P = vc.adapter;
				*SHORT18P = vc.monitor;
				*SHORT20P = vc.memory;
				len = sizeof(short) * 11;
				break;

			case op_imagesize:
				*LONG8P = _imagesize(SHORT0, SHORT2, SHORT4,
				          SHORT6);
				len = sizeof(short) * 4 + sizeof(long);
				break;

			case op_lineto:
				*SHORT4P = _lineto(SHORT0, SHORT2);
				len = sizeof(short) * 3;
				break;

			case op_moveto:
				xy = _moveto(SHORT0, SHORT2);
				*SHORT4P = xy.xcoord;
				*SHORT6P = xy.ycoord;
				len = sizeof(short) * 4;
				break;

			case op_outtext:
				_outtext(bp);
				len = strlen(bp) + 1;
				break;

			case op_pie:
				*SHORT18P = _pie(SHORT0, SHORT2, SHORT4,
				            SHORT6, SHORT8, SHORT10, SHORT12,
				            SHORT14, SHORT16);
				len = sizeof(short) * 10;
				break;

			case op_rectangle:
				*SHORT10P = _rectangle(SHORT0, SHORT2, SHORT4,
				            SHORT6, SHORT8);
				len = sizeof(short) * 6;
				break;

			case op_remapallpalette:
				*(short *)(bp + 64) = _remapallpalette(LONG0P);
				len = sizeof(long) * 16 + sizeof(short);
				break;

			case op_remappalette:
				*LONG6P = _remappalette(SHORT0, LONG2);
				len = sizeof(short) + sizeof(long) * 2;
				break;

			case op_selectpalette:
				*SHORT2P = _selectpalette(SHORT0);
				len = sizeof(short) * 2;
				break;

			case op_setactivepage:
				*SHORT2P = _setactivepage(SHORT0);
				len = sizeof(short) * 2;
				break;

			case op_setbkcolor:
				*LONG4P = _setbkcolor(LONG0);
				len = sizeof(long) * 2;
				break;

			case op_setcliprgn:
				_setcliprgn(SHORT0, SHORT2, SHORT4, SHORT6);
				len = sizeof(short) * 4;
				break;

			case op_setcolor:
				*SHORT2P = _setcolor(SHORT0);
				len = sizeof(short) * 2;
				break;

			case op_setfillmask:
				_setfillmask(bp);
				len = 8;
				break;

			case op_setnullmask:
				_setfillmask(NULL);
				len = 0;
				break;

			case op_setlinestyle:
				_setlinestyle(SHORT0);
				len = sizeof(short);
				break;

			case op_setlogorg:
				xy = _setlogorg(SHORT0, SHORT2);
				*SHORT4P = xy.xcoord;
				*SHORT6P = xy.ycoord;
				len = sizeof(short) * 4;
				break;

			case op_setpixel:
				*SHORT4P = _setpixel(SHORT0, SHORT2);
				len = sizeof(short) * 3;
				break;

			case op_settextcolor:
				*SHORT2P = _settextcolor(SHORT0);
				len = sizeof(short) * 2;
				break;

			case op_settextposition:
				rc = _settextposition(SHORT0, SHORT2);
				*SHORT4P = rc.row;
				*SHORT6P = rc.col;
				len = sizeof(short) * 4;
				break;

			case op_settextwindow:
				_settextwindow(SHORT0, SHORT2, SHORT4, SHORT6);
				len = sizeof(short) * 4;
				break;

			case op_setvideomode:
				*SHORT2P = _setvideomode(SHORT0);
				len = sizeof(short) * 2;
				break;

			case op_setviewport:
				_setviewport(SHORT0, SHORT2, SHORT4, SHORT6);
				len = sizeof(short) * 4;
				break;

			case op_setvisualpage:
				*SHORT2P = _setvisualpage(SHORT0);
				len = sizeof(short) * 2;
				break;

			case op_wrapon:
				*SHORT2P = _wrapon(SHORT0);
				len = sizeof(short) * 2;
				break;

			case op_kbhit:
				*SHORT0P = kbhit();
				len = sizeof(short);
				break;

			case op_bios_keybrd:
				*SHORT2P = _bios_keybrd(SHORT0);
				len = sizeof(short) * 2;
				break;

			default:
				printf("Bad graphics command: %d\n",
					*(bp-1));
				return;

		}

		/* Increment the buffer pointer to the next command. */

		bp += len;

	}

	/* Return back to the protected mode caller. */

	return;

}
