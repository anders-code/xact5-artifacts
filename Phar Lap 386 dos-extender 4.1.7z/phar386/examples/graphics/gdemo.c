/* gdemo.c - Graphics demo program */

/************************************************************************/
/*	Copyright (C) 1986-1988 Phar Lap Software, Inc.			*/
/*	Unpublished - rights reserved under the Copyright Laws of the	*/
/*	United States.  Use, duplication, or disclosure by the 		*/
/*	Government is subject to restrictions as set forth in 		*/
/*	subparagraph (c)(1)(ii) of the Rights in Technical Data and 	*/
/*	Computer Software clause at 252.227-7013.			*/
/*	Phar Lap Software, Inc., 60 Aberdeen Ave., Cambridge, MA 02138	*/
/************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/*
 * Include the Microsoft graphics library definition file.  Before we do
 * this, we will undefine the keywords cdecl and far so that we will
 * be able to compile the function prototypes.  High C-386 v1.6 doesn't
 * like the cdecl keyword and we don't really need it anyway.
 * We undefine the far keyword because protected mode programs run
 * in flat model and will want to pass in near pointers to buffers
 * when they call graphics routines.
 */
#undef cdecl
#undef far
#define cdecl
#define far
#include "graph.h"
#undef far
#undef cdecl

/*

main - Main routine

*/

main()

{

	struct videoconfig vc;	/* Video configuration */
	int btime;		/* Execution time for buffered mode */
	int ubtime;		/* Execution time for unbuffered mode */

	/* Get the current video mode */

	_getvideoconfig(&vc);

	/* Switch to CGA high res black/white graphics mode */

	_setvideomode(_HRESBW);

	/* Run the demo first in buffered mode if protected mode */

	_gbuffmode(1);
	btime = randline();
	
	/* Run the demo again in unbuffered mode */

	_gbuffmode(0);
	ubtime = randline();

	/* Restore the original video mode */

	_setvideomode(vc.mode);

	/* Print out the buffered and unbuffered execution times */

	printf("\n\n");
	printf("Buffered mode execution time = %i milliseconds.\n",
	       btime);
	printf("Unbuffered mode execution time = %i milliseconds.\n",
	       ubtime);

	/* Exit back to DOS */

	return 0;	

}


/*

randline - Random line demo

*/

int randline()

{

	int i;		/* Loop counter */
	clock_t stime;	/* Start type */
	clock_t etime;	/* End time */

	/* Reseed the random number generator to a constant 100 so that
	   we always generate the same random lines. */

	srand(100);

	/* Start the clock */

	stime = clock();

	/* The demo code clears the screen and randomly draws 1000 lines */

	_clearscreen(_GCLEARSCREEN);
	for(i = 0; i < 1000; ++i)
	{
		_fmoveto(randx(), randy());
		_lineto(randx(), randy());
	}

	/* Stop the clock */

	etime = clock();

	/* Return withe the elapse execution time in milliseconds */

	return (int)((1000L * (etime - stime)) / CLK_TCK);

}


/*

randx - Generate a random X coordinate value

*/

int randx()

{
	
	return rand() % 640;

}


/*

randy - Generate a random Y coordinate value

*/

int randy()

{
	
	return rand() % 200;

}
