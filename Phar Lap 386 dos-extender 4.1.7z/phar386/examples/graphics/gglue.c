/* gglue.c - Graphics glue routines */

/************************************************************************/
/*	Copyright (C) 1986-1988 Phar Lap Software, Inc.			*/
/*	Unpublished - rights reserved under the Copyright Laws of the	*/
/*	United States.  Use, duplication, or disclosure by the 		*/
/*	Government is subject to restrictions as set forth in 		*/
/*	subparagraph (c)(1)(ii) of the Rights in Technical Data and 	*/
/*	Computer Software clause at 252.227-7013.			*/
/*	Phar Lap Software, Inc., 60 Aberdeen Ave., Cambridge, MA 02138	*/
/************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "gserver.h"

/*
 * Include the Microsoft graphics library definition file.  Before we do
 * this, we will undefine the keywords cdecl and far so that we will
 * correctly compile the function prototypes.  High C-386 1.6 doesn't like the
 * cdecl keyword and it is not really necessary (since we know this is C code).
 * We will undefine far because protected mode programs are going to
 * pass in near pointers to the graphics library routines.
 */
 
#undef cdecl
#undef far
#define cdecl
#define far

#include "graph.h"

/*
 * The communications buffer pointer and size variables 
 * appear in prot.asm
 */
extern GBPTR _gbuffp;	/* Pointer to the graphics communications buffer */
extern int _gbuffsize;	/* Size in bytes of the communications buffer */

int _gbuff_flag;	/* Buffered mode flag - TRUE = buffered, FALSE =
			   unbuffered */

unsigned long _server_ptr; /* Real mode address of the graphics server */

unsigned long _rbuffp;	/* Real mode address of the communucations buffer */

int _gopenf = {0};	/* Graphics server is open flag */

char def_dname[] = "gserver.drv";	/* Default name of the graphics
					   server */

onexit_t _gexitfp = {0};		/* On exit function pointer for
					   use by _gclose */
	  
int _gregf = {0};			/* "_gclose" has been registered
					   with "exit" flag */

/*
 * Forward function declarations
 */
onexit_t _gclose();
void _gflush();
int _gbuffmode();

/*
 * Functions which appear in prot.asm
 */
extern void realcall();
extern void realexit();
extern int realload();
extern unsigned long prottoreal();

/*

_gopen - Open the graphics server

This routine is called to open the real mode graphics server.  It is
passed in the address of the name of the file that contains the real
mode server code.  Since this routine does no searching of the PATH
environment variable, the file name must contain a directory path or the
file must be located in the current directory.  

The open process consists of the following steps:

	1).  The real mode server is loaded into memory

	2).  Its initialization routine is called
	
	3).  The communications buffer is marked as empty

	4).  The communications buffer is set to buffered mode

If the open is successful, then this routine returns 0.  If the
open is unsuccessful, then this routine prints out an error message
and termintes the program.

*/

int _gopen(fnp)

char *fnp;		/* Pointer to the name of the .EXE file that contains
			   the graphics server. */

{

	int rc;			/* Return code */

	/* Make a quick return if the server is already open */

	rc = 0;
	if(_gopenf)
		goto ret1;

	/* Load and initialize the real mode graphics server */

	rc = realload(fnp, &_server_ptr);

	/* If there was a load error terminate the program */

	if(rc)
	{
		printf("Error loading real mode graphics server: %s: ", fnp);
		switch(rc)
		{
		case 2:
			printf("file not found\n");
			break;
		case 5:
			printf("access denied\n");
			break;
		case 8:
			printf("insufficient memory\n");
			break;
		case 10:
			printf("invalid environment segment\n");
			break;
		case 11:
			printf("invalid file format\n");
			break;
		default:
			printf("error code=%d\n", rc);
			break;
		}
		exit(rc);
	}

	/* Mark the communications buffer as empty. */

	*(GBSPTR)_gbuffp = sizeof(short);

	/* Convert the protected mode address of the communications
	   buffer to a real mode address for use when the real
	   mode server is called. */

	_rbuffp = prottoreal(_gbuffp, 0x14);
	
	/* Start the graphics server in buffered mode. */

	_gbuff_flag = 1;

	/* Turn on the open flag */

	_gopenf = 1;

	/* Register _gclose to be called at exit time */

	if(!_gregf)
	{
		_gregf = 1;
		_gexitfp = onexit(_gclose);
	}

	/* Return to the calller */

ret1:	return rc;

}


/*

_gclose - Close the graphics driver

This routine is called to close the real mode graphics server.  
The following steps are performed in the close process:

	1).  Any existing commands in the communications buffer
	     are executed.

	2).  The server is told to exit and it
	     does any necessary clean-up operations.

	3).  The real mode memory allocated to the server is freed.

*/

onexit_t _gclose()

{

	/* Switch on the current state of the open flag.  This switch
	   is required in case we are re-entered due to an abnormal error
	   exit from "_gflush" or "realexit". */

	switch(_gopenf)
	{

	/* First flush any commands in the communications buffer */

	case 1:
		++_gopenf;
		_gflush();

	/* Then tell the real mode code to exit */

	case 2:
		++_gopenf;
		realexit();
		
	/* Then turn off the open flag */

	default:
		_gopenf = 0;
		break;
		
	}

	/* Return */

	return _gexitfp;

}


/*

_gbuffmode - Set video buffering mode

This routine is called to change the buffering mode for communications
buffer.  The routine takes a single argument which is the new mode. A
value of zero means unbuffered and a value of one means buffered.  The
routine returns as a function result the old mode.

*/

int _gbuffmode(newmode)

int newmode;		/* New buffering mode */

{

	int oldmode;		/* Old buffering mode */

	if(!_gopenf)
		_gopen(def_dname);
	oldmode = _gbuff_flag;
	_gbuff_flag = newmode;
	if(!newmode)
		_gflush();

	return oldmode;

}


/* 

_galloc - Allocate space in the communications buffer

This routine is used by the glue routines to allocate space
in the communications buffer.  The caller passes in the number
of bytes that it needs in the communications buffer to hold
a command.  If this number of bytes are available, then the
routine returns immediately with a pointer
into the buffer where the command can be placed.  If the
space is not available, then the real mode server is called to
empty out the buffer in order to make room for the new command.
When the server is all done, this routine returns with a 
pointer to the empty communications buffer.

*/

GBPTR _galloc(n)

unsigned n;		/* Number of bytes needed */

{

	register GBPTR bp;		/* Buffer pointer */
	GBPTR rp;			/* Returned pointer */

	/* If the server is not open, then open to the default server */

	if(!_gopenf)
		_gopen(def_dname);

	/* If the communications buffer does not have enough room for
	   the number of bytes requested by the caller, then flush the buffer
	   by executing all of the commands in it in order to make room. */

	bp = _gbuffp;
	if(SHORT0 + n > _gbuffsize)
		_gflush();

	/* Calculate the return pointer for the caller */

	rp = bp + SHORT0;

	/* Increment the used byte count that is located in the first 2
	   bytes of the buffer */

	*SHORT0P += n;

	/* Return */

	return rp;
}

/*

_gflush - Flush the communications buffer

This routine is called to flush the communications buffer.  If
the buffer is not empty, then this routine calls the real mode
server to execute all of the commands in the buffer.  The buffer
is then marked as empty.

*/

void _gflush()

{

	register GBPTR bp;		/* Buffer pointer */


	/* If the server is not open, then return */

	if(!_gopenf)
		return;

	/* If the communications buffer is not empty, then call
	   then real mode server to execute the graphics commands
	   in the buffer. */

	bp = _gbuffp;
	if(SHORT0 > sizeof(short))
		realcall(_server_ptr, _rbuffp);

	/* Empty out the buffer by setting the use count at the front
	   of the buffer to the size of the use count. */

	*SHORT0P = sizeof(short);

}		


/*

_arc - _arc glue routine 

*/

short  _arc(short x1, short y1, short x2, short y2,
               short x3, short y3, short x4, short y4)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 9 + 1);
	*bp++ = op_arc;
	*SHORT0P = x1;
	*SHORT2P = y1;
	*SHORT4P = x2;
	*SHORT6P = y2;
	*SHORT8P = x3;
	*SHORT10P = y3;
	*SHORT12P = x4;
	*SHORT14P = y4;
	if(!_gbuff_flag)
	{
		_gflush();
		return SHORT16;
	}
	return 1;

}


/*

_clearscreen - _clearscreen glue routine

*/

void  _clearscreen(short area)

{

	register GBPTR bp;

	bp = _galloc(sizeof(short) + 1);
	*bp++ = op_clearscreen;
	*SHORT0P = area;
	if(!_gbuff_flag)
		_gflush();
	return;

}


/*

_displaycursor - _displaycursor glue routine 

*/

short  _displaycursor(short n)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 2 + 1);
	*bp++ = op_displaycursor;
	*SHORT0P = n;
	_gflush();
	return SHORT2;

}


/*

_ellipse - _ellipse glue routine 

*/

short  _ellipse(short c, short x1, short y1, short x2, short y2)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 6 + 1);
	*bp++ = op_ellipse;
	*SHORT0P = c;
	*SHORT2P = x1;
	*SHORT4P = y1;
	*SHORT6P = x2;
	*SHORT8P = y2;
	if(!_gbuff_flag)
	{
		_gflush();
		return SHORT10;
	}
	return 1;

}


/*

_floodfill - _floodfill glue routine 

*/

short  _floodfill(short x, short y, short b)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 4 + 1);
	*bp++ = op_floodfill;
	*SHORT0P = x;
	*SHORT2P = y;
	*SHORT4P = b;
	if(!_gbuff_flag)
	{
		_gflush();
		return SHORT6;
	}
	return 1;

}


/*

_fmoveto - Fast _moveto glue routine (buffered)

*/

void  _fmoveto(short x, short y)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 4 + 1);
	*bp++ = op_moveto;
	*SHORT0P = x;
	*SHORT2P = y;
	if(!_gbuff_flag)
		_gflush();
	return;

}


/*

_getbkcolor - _getbkcolor glue routine 

*/

long  _getbkcolor(void)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(long) + 1);
	*bp++ = op_getbkcolor;
	_gflush();
	return LONG0;

}


/*

_getcolor - _getcolor glue routine 

*/

short  _getcolor(void)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 1 + 1);
	*bp++ = op_getcolor;
	_gflush();
	return SHORT0;

}


/*

_getcurrentposition - _getcurrentposition glue routine 

*/

struct xycoord  _getcurrentposition(void)

{

	register GBPTR bp;		/* Buffer pointer */
	struct xycoord xy;		/* X-Y return value */

	bp = _galloc(sizeof(short) * 2 + 1);
	*bp++ = op_getcurrentposition;
	_gflush();
	xy.xcoord = SHORT0;
	xy.ycoord = SHORT2;
	return xy;

}


/*

_getfillmask - _getfillmask glue routine 

*/

unsigned char *_getfillmask(register unsigned char *mp)

{

	register GBPTR bp;		/* Buffer pointer */
	int i;				/* Loop counter */

	bp = _galloc(sizeof(short) + 8 + 1);
	*bp++ = op_getfillmask;
	_gflush();
	if(!SHORT8)
		return NULL;
	for(i = 0; i < 8; ++i)
		*mp++ = *bp++;
	return mp - 8;

}


/*

_getlinestyle - _getlinestyle glue routine 

*/

unsigned short  _getlinestyle(void)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 1 + 1);
	*bp++ = op_getlinestyle;
	_gflush();
	return (unsigned short)SHORT0;

}


/*

_getlogcoord - _getlogcoord glue routine 

*/

struct xycoord  _getlogcoord(short x, short y)

{

	register GBPTR bp;		/* Buffer pointer */
	struct xycoord xy;		/* X-Y return value */

	bp = _galloc(sizeof(short) * 4 + 1);
	*bp++ = op_getlogcoord;
	*SHORT0P = x;
	*SHORT2P = y;
	_gflush();
	xy.xcoord = SHORT4;
	xy.ycoord = SHORT6;
	return xy;

}


/*

_getphyscoord - _getphyscoord glue routine 

*/

struct xycoord  _getphyscoord(short x, short y)

{

	register GBPTR bp;		/* Buffer pointer */
	struct xycoord xy;		/* X-Y return value */

	bp = _galloc(sizeof(short) * 4 + 1);
	*bp++ = op_getphyscoord;
	*SHORT0P = x;
	*SHORT2P = y;
	_gflush();
	xy.xcoord = SHORT4;
	xy.ycoord = SHORT6;
	return xy;

}


/*

_getpixel - _getpixel glue routine

*/

short  _getpixel(short x, short y)

{

	register GBPTR bp;

	bp = _galloc(sizeof(short) * 3 + 1);
	*bp++ = op_getpixel;
	*SHORT0P = x;
	*SHORT2P = y;
	_gflush();
	return SHORT4;

}


/*

_gettextcolor - _gettextcolor glue routine 

*/

short  _gettextcolor(void)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 1 + 1);
	*bp++ = op_gettextcolor;
	_gflush();
	return SHORT0;

}


/*

_gettextposition - _gettextposition glue routine 

*/

struct rccoord  _gettextposition(void)

{

	register GBPTR bp;		/* Buffer pointer */
	struct rccoord rc;		/* Row/column structure */

	bp = _galloc(sizeof(short) * 2 + 1);
	*bp++ = op_gettextposition;
	_gflush();
	rc.row = SHORT0;
	rc.col = SHORT2;
	return rc;

}


/*

_getvideoconfig - _getvideoconfig glue routine 

*/

struct videoconfig *_getvideoconfig(struct videoconfig *p)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 7 + 1);
	*bp++ = op_getvideoconfig;
	_gflush();
	p->numxpixels = SHORT0;
	p->numypixels = SHORT2;
	p->numtextcols = SHORT4;
	p->numtextrows = SHORT6;
	p->numcolors = SHORT8;
	p->bitsperpixel = SHORT10;
	p->numvideopages = SHORT12;
	p->mode = SHORT14;
	p->adapter = SHORT16;
	p->monitor = SHORT18;
	p->memory = SHORT20;
	return p;

}


/*

_imagesize - _imagesize glue routine 

*/

long  _imagesize(short x1, short y1, short x2, short y2)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 4 + sizeof(long) + 1);
	*bp++ = op_imagesize;
	*SHORT0P = x1;
	*SHORT2P = y1;
	*SHORT4P = x2;
	*SHORT6P = y2;
	_gflush();
	return LONG8;

}


/*

_lineto - _lineto glue routine

*/

short  _lineto(short x, short y)

{

	register GBPTR bp;

	bp = _galloc(sizeof(short) * 3 + 1);
	*bp++ = op_lineto;
	*SHORT0P = x;
	*SHORT2P = y;
	if(!_gbuff_flag)
	{
		_gflush();
		return SHORT4;
	}
	return 1;

}


/*

_moveto - _moveto glue routine

*/

struct xycoord  _moveto(short x, short y)

{

	register GBPTR bp;		/* Buffer pointer */
	struct xycoord ppnt;		/* Previous point */

	bp = _galloc(sizeof(short) * 3 + 1);
	*bp++ = op_moveto;
	*SHORT0P = x;
	*SHORT2P = y;
	_gflush();
	ppnt.xcoord= SHORT4;
	ppnt.ycoord = SHORT6;
	return ppnt;

}


/*

_outtext - _outtext glue routine 

*/

void  _outtext(char *p)

{

	register GBPTR bp;	/* Buffer pointer */
	int n;			/* String length */
	int cc;			/* Cycle count */
	int i;			/* Buffer copy count */

	n = strlen(p);
	while(1)
	{
		cc = n;
		if(cc > _gbuffsize - 2)
			cc = _gbuffsize - 2;
		bp = _galloc(cc + 2);
		*bp++ = op_outtext;
		for(i = 0; i < cc; ++i)
			*(bp+i) = *(p+i);
		*(bp + cc) = 0;
		n -= cc;
		if(n == 0)
			break;
		_gflush();
	}

}


/*

_pie - _pie glue routine 

*/

short  _pie(short c, short x1, short y1, short x2, short y2,
               short x3, short y3, short x4, short y4)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 10 + 1);
	*bp++ = op_pie;
	*SHORT0P = c;
	*SHORT2P = x1;
	*SHORT4P = y1;
	*SHORT6P = x2;
	*SHORT8P = y2;
	*SHORT10P = x3;
	*SHORT12P = y3;
	*SHORT14P = x4;
	*SHORT16P = y4;
	if(!_gbuff_flag)
	{
		_gflush();
		return SHORT18;
	}
	return 1;

}


/*

_rectangle - _rectangle glue routine 

*/

short  _rectangle(short c, short x1, short y1, short x2, short y2)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 6 + 1);
	*bp++ = op_rectangle;
	*SHORT0P = c;
	*SHORT2P = x1;
	*SHORT4P = y1;
	*SHORT6P = x2;
	*SHORT8P = y2;
	if(!_gbuff_flag)
	{
		_gflush();
		return SHORT10;
	}
	return 1;

}


/*

_remapallpalette - _rempallpalette glue routine 

*/

short  _remapallpalette(long *p)

{

	register GBPTR bp;		/* Buffer pointer */
	int i;

	bp = _galloc(sizeof(long) * 16 + sizeof(short) + 1);
	*bp++ = op_remapallpalette;
	for(i = 0; i < (sizeof(long) * 16); ++i)
		*(bp+i) = *(p+i);
	bp += sizeof(long) * 16;
	if(!_gbuff_flag)
	{
		_gflush();
		return *(GBSPTR)bp;
	}
	return 0;

}


/*

_remappalette - _remappalette glue routine 

*/

long  _remappalette(short p, long c)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) + sizeof(long) + 1);
	*bp++ = op_remappalette;
	*SHORT0P = p;
	*LONG2P = c;
	_gflush();
	return LONG6;

}


/*

_selectpalette - _selectpalette glue routine 

*/

short  _selectpalette(short n)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 2 + 1);
	*bp++ = op_selectpalette;
	*SHORT0P = n;
	_gflush();
	return SHORT2;

}


/*

_setactivepage - _setactivepage glue routine 

*/

short  _setactivepage(short n)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 2 + 1);
	*bp++ = op_setactivepage;
	*SHORT0P = n;
	_gflush();
	return SHORT2;

}


/*

_setbkcolor - _setbkcolor glue routine 

*/

long  _setbkcolor(long c)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(long) * 2 + 1);
	*bp++ = op_setbkcolor;
	*LONG0P = c;
	_gflush();
	return LONG4;

}


/*

_setcliprgn - _setcliprgn glue routine 

*/

void  _setcliprgn(short x1, short y1, short x2, short y2)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 4 + 1);
	*bp++ = op_setcliprgn;
	*SHORT0P = x1;
	*SHORT2P = y1;
	*SHORT4P = x2;
	*SHORT6P = y2;
	if(!_gbuff_flag)
		_gflush();
	return;

}


/*

_setcolor - _setcolor glue routine 

*/

short  _setcolor(short c)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 2 + 1);
	*bp++ = op_setcolor;
	*SHORT0P = c;
	_gflush();
	return SHORT2;

}


/*

_setfillmask - _setfillmask glue routine 

*/

void  _setfillmask(unsigned char *p)

{

	register GBPTR bp;		/* Buffer pointer */
	int i;

	if(p == NULL)
	{
		bp = _galloc(1);
		*bp++ = op_setnullmask;
	}
	else
	{
		bp = _galloc(8 + 1);
		*bp++ = op_setfillmask;
		for(i = 0; i < 8; ++i)
			*(bp+i) = *(p+i);
	}
	if(!_gbuff_flag)
		_gflush();
	return;

}


/*

_setlinestyle - _setlinestyle glue routine 

*/

void  _setlinestyle(unsigned short m)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) + 1);
	*bp++ = op_setlinestyle;
	*SHORT0P = m;
	if(!_gbuff_flag)
		_gflush();
	return;

}


/*

_setlogorg - _setlogorg glue routine 

*/

struct xycoord  _setlogorg(short x, short y)

{

	register GBPTR bp;		/* Buffer pointer */
	struct xycoord xy;		/* X-Y return value */

	bp = _galloc(sizeof(short) * 4 + 1);
	*bp++ = op_setlogorg;
	*SHORT0P = x;
	*SHORT2P = y;
	_gflush();
	xy.xcoord = SHORT4;
	xy.ycoord = SHORT6;
	return xy;

}


/*

_setpixel - _setpixel glue routine 

*/

short  _setpixel(short x, short y)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 3 + 1);
	*bp++ = op_setpixel;
	*SHORT0P = x;
	*SHORT2P = y;
	_gflush();
	return SHORT4;

}


/*

_settextcolor - _settextcolor glue routine 

*/

short  _settextcolor(short c)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 2 + 1);
	*bp++ = op_settextcolor;
	*SHORT0P = c;
	_gflush();
	return SHORT2;

}


/*

_settextposition - _settextposition glue routine 

*/

struct rccoord  _settextposition(short r, short c)

{

	register GBPTR bp;		/* Buffer pointer */
	struct rccoord rc;		/* X-Y return value */

	bp = _galloc(sizeof(short) * 4 + 1);
	*bp++ = op_settextposition;
	*SHORT0P = r;
	*SHORT2P = c;
	_gflush();
	rc.row = SHORT4;
	rc.col = SHORT6;
	return rc;

}


/*

_settextwindow - _settextwindow glue routine 

*/

void  _settextwindow(short r1, short c1, short r2, short c2)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 4 + 1);
	*bp++ = op_settextwindow;
	*SHORT0P = r1;
	*SHORT2P = c1;
	*SHORT4P = r2;
	*SHORT6P = c2;
	if(!_gbuff_flag)
		_gflush();
	return;
	

}


/*

_setvideomode - _setvideomode glue routine

*/

short  _setvideomode(short mode)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 2 + 1);
	*bp++ = op_setvideomode;
	*SHORT0P = mode;
	_gflush();
	return SHORT2;

}


/*

_setviewport - _setviewport glue routine 

*/

void  _setviewport(short x1, short y1, short x2, short y2)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 4 + 1);
	*bp++ = op_setviewport;
	*SHORT0P = x1;
	*SHORT2P = y1;
	*SHORT4P = x2;
	*SHORT6P = y2;
	if(!_gbuff_flag)
		_gflush();
	return;

}


/*

_setvisualpage - _setvisualpage glue routine 

*/

short  _setvisualpage(short n)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 2 + 1);
	*bp++ = op_setvisualpage;
	*SHORT0P = n;
	_gflush();
	return SHORT2;

}


/*

_wrapon - _wrapon glue routine 

*/

short _wrapon(short n)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 2 + 1);
	*bp++ = op_wrapon;
	*SHORT0P = n;
	_gflush();
	return SHORT2;

}


/*

kbhit - kbhit glue routine 

*/

int kbhit(void)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) + 1);
	*bp++ = op_kbhit;
	_gflush();
	return SHORT0;

}


/*

_bios_keybrd - _bios_keybrd glue routine 

*/

unsigned _bios_keybrd(unsigned n)

{

	register GBPTR bp;		/* Buffer pointer */

	bp = _galloc(sizeof(short) * 2 + 1);
	*bp++ = op_bios_keybrd;
	*SHORT0P = n;
	_gflush();
	return SHORT2;

}
