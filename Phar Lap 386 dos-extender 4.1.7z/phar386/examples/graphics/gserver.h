/* gserver.h - Graphics server header file */

/************************************************************************/
/*	Copyright (C) 1986-1988 Phar Lap Software, Inc.			*/
/*	Unpublished - rights reserved under the Copyright Laws of the	*/
/*	United States.  Use, duplication, or disclosure by the 		*/
/*	Government is subject to restrictions as set forth in 		*/
/*	subparagraph (c)(1)(ii) of the Rights in Technical Data and 	*/
/*	Computer Software clause at 252.227-7013.			*/
/*	Phar Lap Software, Inc., 60 Aberdeen Ave., Cambridge, MA 02138	*/
/************************************************************************/

/*

This file contains definitions for the graphics server
example program for 386|DOS-Extender.  It is included both 
by the real and protected mode sides of the server code.
It defines the protocol that the real and protected mode
code use to communication.  The file contains the following
definitions:

	* Command codes
	* Offsets in the communications buffer of arguments

*/

/*
 * We will define data types for pointers into the
 * graphics communications buffer.  When using the -REALBREAK method,
 * these are 32-bit near pointers.  When using the -CALLBUFS method,
 * these are 48-bit far pointers.
 *
 * When this module is compiled in real mode, it will be in large
 * model, so either of these definitions will work fine because
 * all pointers default to far pointers in large model.
 */
#ifdef REALBREAK
typedef char *GBPTR;
typedef short *GBSPTR;
typedef long *GBLPTR;
#else
typedef char _far *GBPTR;
typedef short _far *GBSPTR;
typedef long _far *GBLPTR;
#endif

/* 

Command codes

*/

#define op_arc			1
#define op_clearscreen		2
#define op_displaycursor	3
#define op_ellipse		4
#define op_floodfill		5
#define op_getbkcolor		6
#define op_getcolor		7
#define op_getcurrentposition	8
#define op_getextposition	9
#define op_getfillmask		10
#define op_getimage		11
#define op_getlinestyle		12
#define op_getlogcoord		13
#define op_getphyscoord		14
#define op_getpixel		15
#define op_gettextcolor		16
#define op_gettextposition	17
#define op_getvideoconfig	18
#define op_imagesize		19
#define op_lineto		20	
#define op_logorg		21
#define op_moveto		22
#define op_outtext		23
#define op_pie			24
#define op_putimage		25
#define op_rectangle		26
#define op_remapallpalette	27
#define op_remappalette		28
#define op_selectpalette	29
#define op_setactivepage	30
#define op_setbkcolor		31	
#define op_setcliprgn		32
#define op_setcolor		33
#define op_setfillmask		34
#define op_setlinestyle		35
#define op_setlogorg		36
#define op_setpixel		37
#define op_settextcolor		38
#define op_settextposition	39
#define op_settextwindow	40	
#define op_setvideomode		41
#define op_setviewport		42
#define op_setvisualpage	43
#define op_wrapon		44
#define op_setnullmask		45
#define op_kbhit		46
#define op_bios_keybrd		47


/*

Defines for offsets of arguments in the communications buffer

*/

#define SHORT0P		((GBSPTR)(bp + 0))
#define SHORT2P		((GBSPTR)(bp + 2))
#define SHORT4P		((GBSPTR)(bp + 4))
#define SHORT6P		((GBSPTR)(bp + 6))
#define SHORT8P		((GBSPTR)(bp + 8))
#define SHORT10P	((GBSPTR)(bp + 10))
#define SHORT12P	((GBSPTR)(bp + 12))
#define SHORT14P	((GBSPTR)(bp + 14))
#define SHORT16P	((GBSPTR)(bp + 16))
#define SHORT18P	((GBSPTR)(bp + 18))
#define SHORT20P	((GBSPTR)(bp + 20))

#define SHORT0		(*SHORT0P)
#define SHORT2		(*SHORT2P)
#define SHORT4		(*SHORT4P)
#define SHORT6		(*SHORT6P)
#define SHORT8		(*SHORT8P)
#define SHORT10		(*SHORT10P)
#define SHORT12		(*SHORT12P)
#define SHORT14		(*SHORT14P)
#define SHORT16		(*SHORT16P)
#define SHORT18		(*SHORT18P)
#define SHORT20		(*SHORT20P)

#define LONG0P		((GBLPTR)(bp + 0))
#define LONG2P		((GBLPTR)(bp + 2))
#define LONG4P		((GBLPTR)(bp + 4))
#define LONG6P		((GBLPTR)(bp + 6))
#define LONG8P		((GBLPTR)(bp + 8))
#define LONG10P		((GBLPTR)(bp + 10))
#define LONG12P		((GBLPTR)(bp + 12))
#define LONG14P		((GBLPTR)(bp + 14))
#define LONG16P		((GBLPTR)(bp + 16))

#define LONG0		(*LONG0P)
#define LONG2		(*LONG2P)
#define LONG4		(*LONG4P)
#define LONG6		(*LONG6P)
#define LONG8		(*LONG8P)
#define LONG10		(*LONG10P)
#define LONG12		(*LONG12P)
#define LONG14		(*LONG14P)
#define LONG16		(*LONG16P)

